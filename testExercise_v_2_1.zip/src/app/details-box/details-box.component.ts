import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-box',
  templateUrl: './details-box.component.html',
  styleUrls: ['./details-box.component.sass']
})
export class DetailsBoxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
